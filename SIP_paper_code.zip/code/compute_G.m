function G = compute_G(psi_train, Z, h, l, alpha)

[d,m] = size(Z) ;
[d,n] = size(psi_train);
S1 = sum(2*l)*eye(d) + 2*alpha*(Z.*repmat(l', d, 1))*Z' ;
S2 = repmat(2*h, 1, m) + Z .* repmat((2*alpha*h')*Z, d, 1);
S3 = repmat(2*l,1,d).*(repmat(h', m, 1) + repmat(Z'*(alpha*h), 1, d).*Z');
S4 = diag(h' * h + alpha* (Z' * h).^2 -1) ;

S = [S1,S2;S3,S4];
I = sparse(1:d, 1:d, 1, d+m, d);

G = S' \I;
G = psi_train'*G(1:d,:);

end
