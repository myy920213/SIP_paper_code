% Input:
% pairs: index of pairs. A N*2 matrix where each row is (i, j)
%        We don't really cover all the n*(n-1) pairs of trianing examples
% ytr: an array sized #training-example,
%      the i-th entry is the class of the i-th example (1-10)
% Xtr: a matrix whose i-th row is the raw feature of the i-th training example
% kernel is the structure to compute kernels, it should have several fields
%   kernel.Ksqrt: K_z^{-1/2}
%   kernel.comp_ker(X1, X2): for X1 sized d*n and X2 sized d*m, 
%                             return the kernel matrix sized n*m
%   kernel.gradient
%   kernel.Z
%   kernel.nfea
%   kernel.gamma
function [f, g] = obj_U_mixup(Uvec, pairs, Xtr, ytr_list, alpha, kernel)
  %nfea = size(Xtr, 1);
  
  addpath('../lbfgsb3.0_mex1.2/L-BFGS-B-C-master/Matlab');
    opts.x0=0.5;
    opts.m = 100;
    opts.maxIts=30;
    opts.pgtol=1e-7;
    opts.printEvery=0;
    
  
  nfea = kernel.nfea;
  ntr = size(Xtr, 2);
  nclass = length(Uvec) / nfea;
  U = reshape(Uvec, nfea, []);
  f = 0;
  G = zeros(nfea, nclass);
  KU = kernel.Ksqrt*U;
  for k = 1:size(pairs,1)
     
    i = pairs(k, 1);  j = pairs(k, 2);
    yi = ytr_list(i); yj = ytr_list(j);
    
    % First optimize lambda
    a1 = KU(:,yi);
    a2 = KU(:,yj);    
    obj = @(lambda)obj_lambda(lambda, a1, a2, i, j, Xtr, kernel);
    lambda = lbfgsb(obj, 0,1, opts);
    
    % fa_xlam is the finite approximation of x_lambda
    % g_xlam is the gradient of finite approximation wrt lambda
    [fa_xlam, g_xlam] = comp_xlam(lambda, i, j, Xtr, kernel);  
    obj = (lambda*a1 + (1-lambda)*a2)'*g_xlam + (a1-a2)'*fa_xlam;
    f = f + obj^2;
    G(:,yi) = G(:,yi) + 2*obj*(fa_xlam + lambda*g_xlam);
    G(:,yj) = G(:,yj) + 2*obj*((1-lambda)*g_xlam - fa_xlam); 
  end
  G = kernel.Ksqrt * G;
  g = G(:)/ntr + alpha*Uvec;
  f = f/ntr + alpha/2*norm(Uvec)^2;
  
  
end

% the objective as a fucntion of lambda
function [f, g] = obj_lambda(lambda, a1, a2, i, j, Xtr, kernel)
  [fa_xlam, g_xlam, h_xlam] = comp_xlam(lambda, i, j, Xtr, kernel);
  obj = (lambda*a1 + (1-lambda)*a2)'*g_xlam + (a1-a2)'*fa_xlam;
  f = -(obj^2);
  if nargout > 1
    g = -(2*obj*(2*(a1-a2)'*g_xlam + (lambda*a1+(1-lambda)*a2)'*h_xlam));
  end
end

% Compute f = [k(z_1, x_lambda), ..., k(z_m, x_lambda)]'
% g = first order derivative of f wrt lambda
% h = second order derivative of f wrt lambda
% The kernel structure should carry the Ksqrt as a field
function [f, g, h] = comp_xlam(lambda, i, j, Xtr, kernel)
  f = exp(lambda*kernel.B(:,i) + (1-lambda)*kernel.B(:,j)-lambda*(1-lambda)*kernel.C(i,j));
  temp = (kernel.B(:,i)-kernel.B(:,j)-(1-2*lambda)*kernel.C(i,j));
  if nargout > 1
    g = f.*temp;
  end
  if nargout > 1
    h = g.*temp + f*2*kernel.C(i,j);
  end
end
