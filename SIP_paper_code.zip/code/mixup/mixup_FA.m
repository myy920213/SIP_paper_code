function [base_acc, rkbs_acc] = mixup_FA(seed, train_num, test_num, nfea, npairs, alpha, train_w)

addpath('../../data/mnist_basic');
load('dataset.mat');


addpath('../');



images1 = [train_images; test_images];
images1 = images1';
labels = [train_labels; test_labels];
labels(labels==0) = 10;
 
    clearvars train_images test_images train_labels test_labels
    in_use = train_num+test_num;
   

    
rng(seed);
idx = randperm(size(images1, 2));
train_idx = idx(1:train_num);
test_idx = idx(train_num+1:train_num+test_num);
X_idx = idx(in_use+1:in_use+D);
train_images = normc(images1(:,train_idx));
test_images = normc(images1(:,test_idx));
train_labels = labels(train_idx);
test_labels = labels(test_idx);
train_num = length(train_labels);
test_num = length(test_labels );
class = unique(train_labels);
nclass = length(class);
for i =1:nclass
    train_labels(train_labels==class(i)) = i;
    test_labels(test_labels==class(i)) = i;
end



%% Kmeans initialize Z

D = nfea;
gamma = 2;
miu = 1;

[Z tmp] = mykmeans(normc(train_images),D);
 ind=find(sum(Z.^2)==0);
      if ~isempty(ind)
         Z(:,ind)=rand(size(Z,1),length(ind),'single');
         Z(:,ind)=(bsxfun(@rdivide,Z(:,ind),sqrt(sum(Z(:,ind).^2))));
      end
  Z = normc(Z);
  


%% Nystrom FA

X = [train_images, test_images];  
outmap=kappa(gamma, Z' * X);
   mid = kappa(gamma, Z'*Z);
   [V, S] = eig(mid);
   e = diag(S);
   e = sqrt(e);
   d1 = 1./e;
   K  = V*diag(d1)*V';
   K = real(K);
    A = sqrt(sum(X.^2));
   mid = K*outmap;
  outmap = mid;
   
   psi_train  = outmap(:,1:train_num);
   psi_test = outmap(:, train_num+1:train_num+test_num);
   
   clear V S
   
   
%% vanilla mixup   
   pairs  = randi([1,train_num], npairs, 2);
   image_size = size(train_images,1);
   mix_image = zeros(image_size,npairs);
   label_mix = zeros(nclass, npairs);
   for k=1:npairs
   lambda =betarnd(0.2, 0.2);
   i = pairs(k,1);
   j = pairs(k,2);
   train_1 = train_images(:,i);
   train_2 = train_images(:,j);
   label1 = train_labels(i);
   label2 = train_labels(j);
   mix_image(:,k) = lambda*train_1 + (1-lambda)*train_2;
   label_mix(label1, k) = label_mix(label1, k) + lambda;
   label_mix(label2,k) = label_mix(label2,k) + (1-lambda);
   end 
   psi_mix = K* kappa(gamma, Z' * mix_image);
   
  addpath('../minConf/minConf');
  W0 = rand(D, nclass);
  W0 = W0(:);
  options = [];
  options.maxIter = 50;
  base_acc = 0;
 reg = [1e-2, 5e-3,1e-3, 5e-4, 1e-4, 5e-5, 1e-5, 5e-6, 1e-6, 5e-7, 1e-7, 0];
 for i=1:length(reg)
    obj = @(W)emp_risk(W, psi_mix, label_mix, reg(i));
    funProj = @(u)u;
    opt_W = minConf_PQN(obj,W0,funProj,options);

    opt_W = reshape(opt_W, D, nclass);
     [m,test_pred] = max(opt_W' *psi_test);
     test_acc = test_pred'==test_labels;
     test_acc = sum(test_acc)/test_num*100;
     if test_acc > base_acc
         base_acc = test_acc;
     end
     
 end 
 

%% Embedded mixup 
   kernel.Ksqrt = K;
   kernel.comp_ker = @(x,y,z)compute_ker(x,y,z);
   kernel.Z = Z;
   kernel.nfea = D;
   kernel.gamma = gamma;
   kernel.B = gamma*(Z'*train_images-1);
   kernel.C = gamma*(train_images'*train_images-1);
   
   reg_W = [5e-2, 1e-2, 5e-3, 1e-3, 5e-4, 1e-4, 5e-5, 1e-5, 5e-6, 1e-6, 5e-7, 1e-7, 0];
 [feaCube_tr, feaCube_te] = train_FA([psi_train, psi_test], train_images, train_labels, nclass, alpha, kernel, pairs);
 name = sprintf('tr_%d_%4.2f_%d_%d_%d.mat', seed, alpha, npairs, train_num, nfea);
 savename = ['log/' name];
 save(savename, 'feaCube_tr');
 name = sprintf('te_%d_%4.2f_%d_%d_%d.mat', seed, alpha, npairs, test_num, nfea);
 savename = ['log/' name];
 save(savename, 'feaCube_te');
 
 rkbs_acc = 0;
 opt_reg = 0;
 if train_w == true
     for i = 1:length(reg_W)
         reg = reg_W(i);
         W_init = rand(nfea*nclass,1);
         [opt_W, acc] = train_W(feaCube_tr, feaCube_te, W_init, train_labels, test_labels, reg, true);
         if acc>rkbs_acc
             rkbs_acc = acc;
             opt_reg = reg;
         end
     end

 end
  
   function [f,g] = emp_risk(W, psi, label, reg)
      d = size(psi,1);
      nc = size(label,1);
      W = reshape(W, d, nc);
      fx = W' *psi;
      [L, dLdfx] = softmax(fx, label);
      f = L + reg*norm(W, 'fro')^2;
      g = psi*dLdfx'+ 2*reg * W;
      g = g(:);
   end


end