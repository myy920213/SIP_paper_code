function [L, dLdfx] = mul_hinge(fx, labels)
n = length(labels);
loss = 0;
grad = zeros(size(fx));
for k =1:n
    current = fx(:,k);
    label = labels(k);
    current = current-current(label)+1;
    current(label) = current(label)-1;
    idx = current>0;
    loss = loss+sum(current(idx));
    grad(idx, k) = 1;
    grad(label, k) = -1*length(idx);
end
L = loss/n;
dLdfx = grad/n;
