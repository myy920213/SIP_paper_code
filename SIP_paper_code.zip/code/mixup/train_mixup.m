% Xtr is the raw training data, each column is a training example
% ytr_list is an array sized #training-example,
%          the i-th entry is the class of the i-th example (1-10)
% nclass: number of classes.  It typically equals max(ytr_list), but just
%         in case a class never appears in the training data
% alpha: the weight on ||U||^2 is alpha/2
function [W, Yte_array] = train_mixup(Phi_all, Xtr, ytr_array, nclass, alpha, kernel, pairs, reg_W)
  
  % First create the Phi matrix, whose i-th column is the finite approximation of k(x_i, .)
  % Phi = ...;
  
  % Then create the list of pairs to enforce mixup
  % pairs = ...;
   
  addpath('../minConf/minConf');
  options = [];
  options.maxIter = 50;
  options.progTol = 1e-5;
  options.verbose = 0;
  ntr = size(Xtr, 2);
  Phi = Phi_all(:, 1:ntr);
  Phi_te = Phi_all(:, ntr+1:end);
  nte = size(Phi_te, 2);
  nfea = size(Phi, 1);
  feaCube = zeros(nfea*nclass, nclass, ntr);
  
  obj_U = @(Uvec)obj_U_mixup(Uvec, pairs, Xtr, ytr_array, alpha, kernel);
  
%   opt_fmincon = optimoptions(@fmincon,'Algorithm','interior-point',...
%                         'MaxIterations', 30, 'SpecifyObjectiveGradient', true);
  
  parfor k = 1 : ntr
    opt_U = zeros(nfea*nclass,1);
    U0 = [Phi(:,k)/norm(Phi(:,k))^2, zeros(nfea, nclass-1)];
    for c = 1 : nclass
      if c > 1
        U0 = reshape(opt_U, nfea, nclass);
        U0(:,[c-1,c]) = U0(:, [c,c-1]);
        %U0 = zeros(nfea, nclass);
        %U0(:,c) =  Phi(:,k)/norm(Phi(:,k))^2;
      end
      b = sparse(ones(nfea,1), nfea*(c-1)+1:nfea*c, Phi(:,k), 1, nfea*nclass);
%       [opt_U, feval, exitflag, output] = fmincon(obj_U,U0(:),[],[],...
%                                     b,1,[],[],[],opt_fmincon);
      
      [opt_U, feval] = minConf_PQN(obj_U,U0(:),@(u)proj(u,b'),options);
      feaCube(:,c,k) = opt_U / sqrt(feval);
      
    end
    
  end
  
  % Now output layer to train a classifier
  obj_W = @(Wvec)emp_risk(Wvec, feaCube, ytr_array, reg_W, nfea, ntr, nclass);
  W0 = rand(nfea*nclass,1);
   W_options = [];
   W_options.maxIter = 10;
   projFun = @(w)w;
   [W, feval] = minConf_PQN(obj_W,W0, projFun,W_options); 
%    [f,g] = emp_risk(W0, feaCube, ytr_array, reg_W, nfea, ntr, nclass);
%    [grad,err] = gradest(obj_W, W0);
%    [g, grad']
   
  % Now apply W to test data (multiclass classification)
  % Let Phi_te be the Phi of test data (nfea * nte),
  %   where nte is the number of test examples
  Yte_array = zeros(nte,1); % store the result of prediction
  parfor k = 1 : nte
     opt_Ute = zeros(nfea*nclass,1);
    U0 = [Phi_te(:,k)/norm(Phi_te(:,k))^2, zeros(nfea, nclass-1)];
    score_rec = -inf;
    for c = 1 : nclass
      if c > 1
         U0 = reshape(opt_Ute, nfea, nclass);
         U0(:,[c-1,c]) = U0(:, [c,c-1]);
        %U0 = zeros(nfea, nclass);
        %U0(:,c) =  Phi_te(:,k)/norm(Phi_te(:,k))^2;
      end
      b = sparse(ones(nfea,1), nfea*(c-1)+1:nfea*c, Phi_te(:,k), 1, nfea*nclass);
      [opt_Ute, feval] = minConf_PQN(obj_U,U0(:),@(u)proj(u,b'),options);
      
      %feaCube(:,c,k) = opt_U / sqrt(feval);
      score = W'*(opt_Ute / sqrt(feval));
      if score > score_rec
        score_rec = score;
        Yte_array(k) = c;
      end
    end
  end
end

% let's use logistic loss for multiclass
function [f, g] = emp_risk(Wvec, feaCube, ytr_array, reg_W, nfea, ntr, nclass)
  f = 0;
  train_acc = 0;
  g = zeros(nfea*nclass, 1);
  for k = 1 : ntr
    c = ytr_array(k);
    score = Wvec'*feaCube(:,:,k); % nclass dimensional vector   
    s = score - max(score); % avoid overflow/underflow
    grad = exp(s);
    f = f - s(c) + log(sum(grad)); % log-likelihood of the correct class
    grad = grad / sum(grad);    
    grad(c) = grad(c) - 1;     
    g = g + feaCube(:,:,k)*grad';
    [m,i]=max(score);
    if i == c
        train_acc = train_acc+1;
    end
  end
  f = f/ntr + reg_W/2*norm(Wvec)^2;
  g = g/ntr + reg_W*Wvec;
  train_acc = train_acc/ntr
  
end

function x = proj(u, b)
  lambda = (1-u'*b)/norm(b)^2;
  x = u + lambda*b;
end