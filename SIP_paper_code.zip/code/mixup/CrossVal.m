train_num =500;
test_num = 500;
nfea = 500;
npairs = 1000;
alpha = 0.5;

addpath('../../data/mnist_basic');
load('dataset.mat');


addpath('../');


% images1 = train_images';
images1 = [train_images; test_images];
images1 = images1';
labels = [train_labels; test_labels];
labels(labels==0) = 10;
% labels = train_labels;
%images1 = loadMNISTImages('train-images-idx3-ubyte');
% labels = loadMNISTLabels('train-labels-idx1-ubyte');
 


 
    clearvars train_images test_images train_labels test_labels
    %clearvars -except images1 labels i acc1 acc2
    %train_num = 10000;
    %test_num = 10000;
    %invariance_num = 10000;
    in_use = train_num+test_num;
    D = 1000;

    
rng(0);
idx = randperm(size(images1, 2));
train_idx = idx(1:train_num);
test_idx = idx(train_num+1:train_num+test_num);
X_idx = idx(in_use+1:in_use+D);
train_images = normc(images1(:,train_idx));
test_images = normc(images1(:,test_idx));
train_labels = labels(train_idx);
test_labels = labels(test_idx);
% sele_train = find(train_labels == 2 |train_labels == 5);
% sele_train = sele_train(1:200);
% train_images = train_images(:, sele_train);
% sele_test = find(test_labels == 2 | test_labels == 5);
% sele_test = sele_test(1:200);
% test_images = test_images(:, sele_test);
% train_labels = train_labels(sele_train);
% 
% test_labels = test_labels(sele_test);

train_num = length(train_labels);
test_num = length(test_labels );
%invariance_num = train_num;
class = unique(train_labels);
nclass = length(class);
for i =1:nclass
    train_labels(train_labels==class(i)) = i;
    test_labels(test_labels==class(i)) = i;
end



%% Kmeans initialize Z

D = nfea;
gamma = 2;
miu = 1;
%[Z tmp] = mykmeans(normc(images1(:,X_idx)),D);
[Z tmp] = mykmeans(normc(train_images),D);
 ind=find(sum(Z.^2)==0);
      if ~isempty(ind)
         Z(:,ind)=rand(size(Z,1),length(ind),'single');
         Z(:,ind)=(bsxfun(@rdivide,Z(:,ind),sqrt(sum(Z(:,ind).^2))));
      end
  Z = normc(Z);
  
%   Z = randn(784, D);
%   Z = normc(Z);
 %load('filter.mat'); 

%clear images1;

%% feature mapping

X = [train_images, test_images];



  
%normalizeX = normalization(X);
  
outmap=kappa(gamma, Z' * X);

   mid = kappa(gamma, Z'*Z);
   [V, S] = eig(mid);
   e = diag(S);
   e = sqrt(e);
   d1 = 1./e;
   K  = V*diag(d1)*V';
   K = real(K);
    A = sqrt(sum(X.^2));
   mid = K*outmap;
  % outmap = bsxfun(@times, mid, A);
  outmap = mid;
   
   psi_train  = outmap(:,1:train_num);
   psi_test = outmap(:, train_num+1:train_num+test_num);
   
   %psi_train = normc(psi_train);
   %psi_test = normc(psi_test);
   clear V S
   
   %npairs = 500;
%    maxIter = 20000;
%    lr = 1.0;
%    reg = 1e-6;
%   [test_acc, pairs] = base_SGD(psi_train, train_labels, psi_test, test_labels, nclass, maxIter, lr, reg);
   
   pairs  = randi([1,train_num], npairs, 2);
   %pairs = [1:train_num; 1:train_num]';
   psi_mix = zeros(D, npairs);
   label_mix = zeros(nclass, npairs);
   for k=1:npairs
   lambda =betarnd(0.2,0.2);
   i = pairs(k,1);
   j = pairs(k,2);
   train_1 = psi_train(:,i);
   train_2 = psi_train(:,j);
   label1 = train_labels(i);
   label2 = train_labels(j);
   psi_mix(:,k) = lambda*train_1 + (1-lambda)*train_2;
   label_mix(label1, k) = label_mix(label1, k) + lambda;
   label_mix(label2,k) = label_mix(label2,k) + (1-lambda);
   end
   
   addpath('../minConf/minConf');
 reg_base = [1e-2, 5e-3, 1e-3, 5e-4, 1e-4, 5e-5, 1e-5, 5e-6, 1e-6];
 b_acc = zeros(length(reg_base),1);
 for i=1:length(reg_base)
     W0 = rand(D, nclass);
     W0 = W0(:);
     obj = @(W)emp_risk(W, psi_mix, label_mix, reg_base(i));
    options = [];
    options.maxIter = 30;
    funProj = @(u)u;
    opt_W = minConf_PQN(obj,W0,funProj,options);

    opt_W = reshape(opt_W, D, nclass);
     [m,test_pred] = max(opt_W' *psi_test);
     test_acc = test_pred'==test_labels;
     base_acc = sum(test_acc)/test_num;
     b_acc(i) = base_acc
 end 
base_acc = 0.84;
tr_name = sprintf('log/tr_%4.2f_%4.1f_%d_%d_%d.mat', base_acc, alpha, npairs, train_num, nfea);
te_name = sprintf('log/te_%4.2f_%4.1f_%d_%d_%d.mat', base_acc, alpha, npairs, train_num, nfea);
tr = load(tr_name);
te = load(te_name);
feaCube_tr = tr.feaCube_tr;
feaCube_te = te.feaCube_te;

reg_W = [5e-2, 1e-2, 5e-3, 1e-3, 5e-4, 1e-4, 5e-5, 1e-5, 5e-6, 1e-6];
 test_acc = 0;
 opt_reg = 0;

 mixup_idx = [1:train_num];
 interval = train_num/5;
     for i = 1:length(reg_W)
         reg = reg_W(i);
         current_acc = 0;
         for j  = 1:5
             temp_idx = mixup_idx;
             val_idx = mixup_idx((j-1)*interval+1:j*interval);
             temp_idx(val_idx) = 0;
             tr_idx = mixup_idx(temp_idx>0);
             W_init = rand(nfea*nclass,1);
             [W, acc] = train_W(feaCube_tr(:, :,tr_idx), feaCube_tr(:, :,val_idx), W_init, train_labels, test_labels, reg, true);
             current_acc = current_acc+acc;
         end
         current_acc = current_acc/5;
         if current_acc>test_acc
             test_acc = current_acc;
             opt_reg = reg;
         end
         
     end
     
  W_init = rand(nfea*nclass,1);
  [W, acc] = train_W(feaCube_tr, feaCube_te, W_init, train_labels, test_labels, opt_reg, true);
     
 
 
 
 function [f,g] = emp_risk(W, psi, label, reg)
      d = size(psi,1);
      nc = size(label,1);
      W = reshape(W, d, nc);
      fx = W' *psi;
      [L, dLdfx] = softmax(fx, label);
      f = L + reg*norm(W, 'fro')^2;
      g = psi*dLdfx'+ 2*reg * W;
      g = g(:);
   end
     
     