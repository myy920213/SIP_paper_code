%  #training sample = 500
[vanilla_mixup, embed_mixup] = mixup_FA(0,500,500,500,500,0.1,true)
[vanilla_mixup, embed_mixup] = mixup_FA(0,500,500,500,1000,0.1,true)
[vanilla_mixup, embed_mixup] = mixup_FA(0,500,500,500,2000,0.1,true)

% #training sample = 1000
[vanilla_mixup, embed_mixup] = mixup_FA(0,1000,1000,1000,1000, 0.01,true)
[vanilla_mixup, embed_mixup] = mixup_FA(0,1000,1000,1000,2000, 0.01,true)
[vanilla_mixup, embed_mixup] = mixup_FA(0,1000,1000,1000,4000, 0.01,true)

