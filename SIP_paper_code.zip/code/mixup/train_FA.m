function [feaCube_tr, feaCube_te] = train_FA(Phi_all, Xtr, ytr_array, nclass, alpha, kernel, pairs)

addpath('../minConf/minConf');
  options = [];
  options.maxIter = 50;
  options.progTol = 1e-5;
  options.verbose = 0;
  ntr = size(Xtr, 2);
  Phi = Phi_all(:, 1:ntr);
  Phi_te = Phi_all(:, ntr+1:end);
  nte = size(Phi_te, 2);
  nfea = size(Phi, 1);
  feaCube_tr = zeros(nfea*nclass, nclass, ntr);
  feaCube_te = zeros(nfea*nclass, nclass, nte);
  
  obj_U = @(Uvec)obj_U_mixup(Uvec, pairs, Xtr, ytr_array, alpha, kernel);
  
  
  parfor k = 1 : ntr
    opt_U = zeros(nfea*nclass,1);
    U0 = [Phi(:,k)/norm(Phi(:,k))^2, zeros(nfea, nclass-1)];
    for c = 1 : nclass
        
      if c > 1
        U0 = reshape(opt_U, nfea, nclass);
        U0(:,[c-1,c]) = U0(:, [c,c-1]);
      end
      b = sparse(ones(nfea,1), nfea*(c-1)+1:nfea*c, Phi(:,k), 1, nfea*nclass);
     
      [opt_U, feval] = minConf_PQN(obj_U,U0(:),@(u)proj(u,b'),options);
      feval
      feaCube_tr(:,c,k) = opt_U / sqrt(feval);
     
    end
    
  end
  
   parfor k = 1 : nte
    opt_Ute = zeros(nfea*nclass,1);
    U0 = [Phi_te(:,k)/norm(Phi_te(:,k))^2, zeros(nfea, nclass-1)];
    
    for c = 1 : nclass
      if c > 1
         U0 = reshape(opt_Ute, nfea, nclass);
         U0(:,[c-1,c]) = U0(:, [c,c-1]);
      end
      b = sparse(ones(nfea,1), nfea*(c-1)+1:nfea*c, Phi_te(:,k), 1, nfea*nclass);
      [opt_Ute, feval] = minConf_PQN(obj_U,U0(:),@(u)proj(u,b'),options);
      
      feaCube_te(:,c,k) = opt_Ute / sqrt(feval);

    end
    
   
   end
  
   
end

function x = proj(u, b)
     lambda = (1-u'*b)/norm(b)^2;
     x = u + lambda*b;
end
  
   

