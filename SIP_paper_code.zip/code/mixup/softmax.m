 function  [loss, grad] = softmax(x, y)
        %loss = 0;
        n = size(x,2);
        EXP = exp(x);
        e = sum(EXP);
        EXP = bsxfun(@rdivide, EXP, e);
        %grad=zeros(size(x));
        
        loss = sum(sum(-log(EXP).*y));
        loss = loss/n;
        grad = (EXP-y)/n;
      
        
%         
%         for j = 1:size(y,2)
%            fx = EXP(:,j);
%            label = y(:,j);
%            loss = loss+ (-sum());
%            g = EXP(:,j);
%            g(int8(y(j))) = g(int8(y(j)))-1;
%            grad(:,j) = g;
%            
%            
%         end
 end