function  k  = compute_ker(gamma, X1, X2)
    [d,n]  = size(X1);
    [d,m] = size(X2);
    A =sum( X1.^2);
    B = sum(X2.^2);
    k = exp(gamma/2*(2*X1' * X2 - repmat(A', 1, m) - repmat(B, n, 1)));
end