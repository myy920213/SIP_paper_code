function opt_U  = solve_U(U_init, Kxy, pairs, train_images, train_labels, alpha, kernel)


% addpath('minConf/minConf')
% options = [];
% options.maxIter = 500;
% funObj = @(U)obj_U_mixup(U, pairs, train_images, train_labels, alpha, kernel);
% funProj = @(u)projected(u);
% opt_U = minConf_PQN(funObj,U_init,funProj,options);

%Obj = @(U)obj_U_mixup(U, pairs, train_images, train_labels, alpha, kernel);
%x0 = U_init;
% options = optimoptions(@fminunc, 'SpecifyObjectiveGradient', true,  'Display', 'iter', 'CheckGradients', true, 'FiniteDifferenceStepSize', 1e-8);
% u = fminunc(Obj,x0,options);
[f,g] = obj_U_mixup(U_init, pairs, train_images, train_labels, alpha, kernel);
[grad,err] = gradest(Obj, U_init);
[g, grad']

    function x = projected(u)
     u = reshape(u, [kernel.nfea, Kxy.nclass]);
     x = u;
     x(:,Kxy.label) = u(:,Kxy.label) + (1-Kxy.psi' * u(:,Kxy.label))/(Kxy.psi' * Kxy.psi) * Kxy.psi;
     x = x(:);
end


end