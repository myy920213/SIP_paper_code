function [opt_W, acc] = train_W(feaCube_tr, feaCube_te, W_init, train_labels, test_labels, reg_W, verbose)

[a, nclass, ntr] = size(feaCube_tr);
nfea = a/nclass;
[a, nclass, nte] = size(feaCube_te);

obj_W = @(Wvec)emp_risk(Wvec, feaCube_tr, train_labels, reg_W, nfea, ntr, nclass);
W_options = [];
 W_options.maxIter = 20;
 projFun = @(w)w;
 [opt_W, feval] = minConf_PQN(obj_W,W_init, projFun,W_options); 
 acc = 0;
 for l = 1:nte
        score = opt_W'*feaCube_te(:,:,l);
        [m,i]=max(score);
        if i == test_labels(l)
            acc = acc+1;
        end
  end
    acc = acc/nte*100;

function [f, g] = emp_risk(Wvec, feaCube, ytr_array, reg_W, nfea, ntr, nclass)
  f = 0;
  train_acc = 0;
  test_acc = 0;
  g = zeros(nfea*nclass, 1);
  for k = 1 : ntr
    c = ytr_array(k);
    score = Wvec'*feaCube(:,:,k); % nclass dimensional vector   
    s = score - max(score); % avoid overflow/underflow
    grad = exp(s);
    f = f - s(c) + log(sum(grad)); % log-likelihood of the correct class
    grad = grad / sum(grad);    
    grad(c) = grad(c) - 1;     
    g = g + feaCube(:,:,k)*grad';
    [m,i]=max(score);
    if i == c
        train_acc = train_acc+1;
    end
  end
  f = f/ntr + reg_W/2*norm(Wvec)^2;
  g = g/ntr + reg_W*Wvec;
  
  if verbose ==true
    train_acc = train_acc/ntr*100;
    for j = 1:nte
        score = Wvec'*feaCube_te(:,:,j);
        [m,i]=max(score);
        if i == test_labels(j)
            test_acc = test_acc+1;
        end
    end
    test_acc = test_acc/nte*100;
    
    fprintf('train_acc: %4.2f,    test_acc: %4.2f', train_acc, test_acc);
  end
  
end

end