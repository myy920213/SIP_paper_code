addpath('../data/mnist_basic');
load('dataset.mat');
train_num = 5000;
test_num = 5000;
invariance_num = 5000;

addpath('../');
images1 = [train_images; test_images];
images1 = images1';
labels = [train_labels; test_labels];
    
    clearvars -except images1 labels i acc1 acc2
    train_num = 10000;
    test_num = 10000;
    %invariance_num = 10000;
    in_use = train_num+test_num;
    D = 5000;

    
rng(0);
idx = randperm(size(images1, 2));
train_idx = idx(1:train_num);
test_idx = idx(train_num+1:train_num+test_num);
X_idx = idx(in_use+1:in_use+D);
train_images = normc(images1(:,train_idx));
test_images = normc(images1(:,test_idx));
train_labels = labels(train_idx);
test_labels = labels(test_idx);
sele_train = find(train_labels == 4 |train_labels == 9);
sele_train = sele_train(1:1000);
train_images = train_images(:, sele_train);
sele_test = find(test_labels == 4 | test_labels == 9);
sele_test = sele_test(1:1000);
test_images = test_images(:, sele_test);
train_labels = train_labels(sele_train);
train_labels(find(train_labels==4))=0;
train_labels(find(train_labels==9))=1;
test_labels = test_labels(sele_test);
test_labels(find(test_labels==4))=0;
test_labels(find(test_labels==9))=1;
train_num = length(train_labels);
test_num = length(test_labels );
invariance_num = train_num;



%% Kmeans initialize Z

D = 1000;
alpha = 2
miu = 1;

[Z tmp] = mykmeans(normc(train_images),D);
 ind=find(sum(Z.^2)==0);
      if ~isempty(ind)
         Z(:,ind)=rand(size(Z,1),length(ind),'single');
         Z(:,ind)=(bsxfun(@rdivide,Z(:,ind),sqrt(sum(Z(:,ind).^2))));
      end
  Z = normc(Z);
  

%% feature mapping

X = [train_images, test_images];



  

outmap=kappa(alpha, Z' * X);
   mid = kappa(alpha, Z'*Z);
   [V, S] = eig(mid);
   e = diag(S);
   e = sqrt(e);
   d1 = 1./e;
   K  = V*diag(d1)*V';
   K = real(K);
    A = sqrt(sum(X.^2));
   mid = K*outmap;
  
  outmap = mid;
   
   psi_train  = outmap(:,1:train_num);
   psi_test = outmap(:, train_num+1:train_num+test_num);
   
   clear V S

   
%% gradient invariances

invariance_images = X(:, 1:invariance_num);

[v_rotation,v_transx,v_transy,v_scale] = trans_dev(invariance_images');
V_TRANS = [v_rotation;v_transx; v_transy;v_scale];
V_TRANS = normr(V_TRANS);


map = kappa(alpha, Z' * invariance_images);

[d,N] = size(invariance_images);
[M,d]  = size(V_TRANS); 
r = M/N;
f = repmat(map, 1, r);
train_all = repmat(invariance_images, 1, r);
xv = sum(train_all.*V_TRANS');
X_V = repmat(xv, D, 1);
invariance_inorder = miu*K*(f.*(alpha*(Z' * V_TRANS'-X_V)));

invariance = zeros(D,M);
for i = 1:invariance_num
    invariance(:,(i-1)*4+1) = invariance_inorder(:,i);
    invariance(:,(i-1)*4+2) = invariance_inorder(:,invariance_num+i);
    invariance(:,(i-1)*4+3) = invariance_inorder(:,2*invariance_num+i);
    invariance(:,(i-1)*4+4) = invariance_inorder(:,3*invariance_num+i);
    
end

A = eye(D) + invariance * invariance';
train_matrix = psi_train'*psi_train;
test_matrix = psi_test'*psi_train;
train_matrix_warp = psi_train'/A*psi_train;
test_matrix_warp = psi_test'/A*psi_train;
clear xv X_V f train_all  


[Vec, Sing] = eig(A);
e = diag(Sing);
%e = sqrt(e);
e = e.^(1/2);
d1 = 1./e;
half_A = Vec*diag(d1)*Vec';
psi_train_warp = half_A*psi_train;
psi_test_warp = half_A*psi_test;

clear A Vec Sing half_A

lambda = 1e-3;
l_init = rand(M,1)/train_num;
u_init = rand(D,1);

c_init = randn(train_num,1);
c_init = c_init./100;
verbose = true;

%% plain gaussian svm
[c, min_res] = train_c_plain(psi_train, train_labels, 1e-4, c_init, verbose, psi_test, test_labels);

train_output = psi_train'*psi_train*c;


train_predictions = train_output>=0;

train_acc = sum(train_predictions==train_labels)/train_num

test_out = psi_test'*psi_train*c;

test_predictions = test_out>=0;

test_acc = sum(test_predictions==test_labels)/test_num

%% kernel warping

[c_warp, min_res] = train_c_plain(psi_train_warp, train_labels, 1e-4, c_init, verbose, psi_test_warp, test_labels);

train_output = psi_train_warp'*psi_train_warp*c_warp;

train_predictions = train_output>=0;

train_acc = sum(train_predictions==train_labels)/train_num

test_out = psi_test_warp'*psi_train_warp*c_warp;

test_predictions = test_out>=0;

test_acc = sum(test_predictions==test_labels)/test_num

%% optimize c

a = 100;
verbose = true;
  
[opt_c, opt_loss, opt_l, u_opt, f_res, test_acc] = train_c(psi_train, invariance, train_labels,1e-4, l_init, c_warp, 1, verbose, psi_test, test_labels);


%% Embedding

l_init = rand(M,1);
H = zeros(D, train_num);
store_norm = zeros(train_num,1);
H_final = zeros(D, train_num);
a = 100;
parfor i = 1:train_num
    tic
    [hi, normi] = solve_dual_lbfgsb(l_init, -1.0*psi_train(:,i), invariance, a);
    H(:,i) = hi;
    store_norm(i) = normi;
    H_final(:,i) = normi*hi;
    toc
end


save('mnist_H_final.mat', H_final);
save('mnist_norm.mat', store_norm);
clear H H_final store_norm

a = 100;
[opt_c, opt_loss] = train_FA_c(psi_train, H_final_sum, store_norm_sum, train_labels, a, c_warp, true);
train_output  = psi_train' * H_final_sum * opt_c;
train_predictions = train_output>=0;
train_acc = sum(train_predictions==train_labels)/train_num
test_out = psi_test' * H_final_sum * opt_c;
test_predictions = test_out>=0;
test_acc = sum(test_predictions==test_labels)/test_num

