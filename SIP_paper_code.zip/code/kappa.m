function out = kappa(alpha, x)

out = exp(alpha*(x-1));

end