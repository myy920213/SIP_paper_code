function [c, min_res, l0, opt_u,f_res, test_acc] = train_c(psi_train, invariance, train_labels, lamb, l_init, c_init, a, verbose, psi_test, test_labels)
train_num = length(train_labels);
test_num = length(test_labels);
[d, n] = size(invariance);
%u0 = zeros(d,1);
%f_res = 0;
u0 = l_init;
l0 = l_init;
f_res = 0;
test_acc = 0;
    %opt_u = l_init;
    function [f, g] = c_obj(c)
        
        b = -psi_train*c;
        [opt_u,f_norm, M, opt_l, opt_res] = solve_dual_lbfgsb(l0, b, invariance, a);     %[opt_u, f_norm] = solve_sup(u0, c,psi_train, invariance);
        %[opt_u,f_norm, opt_l, opt_res] = solve_sum_invariance(l0, b, invariance);
        l0 = opt_l;
        u0 = opt_u;
        f_res = f_norm;
        
       %f_norm =  transpose(c)*(transpose(psi_train)*opt_u);
        D = transpose(psi_train)*opt_u;
        fx = f_norm*D;
        %[L, dLdfx] = binary_loss(fx, train_labels);
        %f = L + lamb*f_norm^2;
        [L, dLdfx] = hinge_loss(fx, train_labels);
        f = L + lamb*f_norm^2;
        if nargout > 1
           G = compute_G(psi_train, invariance, opt_u, opt_l, a);
           dfdc = D;
           dhxdc = G*psi_train;
           dfxdc = dfdc*(D') + f_norm*dhxdc;
%            term1 = dfxdc*dLdfx;
%            term2 = lamb*2*f_norm*dfdc;
%            g = term1 + term2;
            term1 = dfxdc*dLdfx;
            term2 = lamb * 2*f_norm*dfdc;
            g = term1 + term2;
            
            if verbose == true
                norm(opt_u);
                train_output = f_res*transpose(psi_train)*opt_u;

                %train_out_prob =  1./(1+exp(-1.*train_output));

                %train_predictions = train_out_prob>=0.5;

                train_predictions = train_output>=0;

                train_acc = sum(train_predictions==train_labels)/train_num;

                test_out = f_res*transpose(psi_test)*opt_u;

                %test_out_prob = 1./(1+exp(-1.*test_out));

                %test_predictions = test_out_prob>=0.5;

                test_predictions = test_out>=0;

                test_acc = sum(test_predictions==test_labels)/test_num;
                fprintf('train_acc: %5.4f   test_acc: %5.4f', train_acc, test_acc);
            end
           
        end
    end


%[f,g] = c_obj(c_init);
%[grad,err] = gradest(@c_obj, c_init);
% 


% x0 = c_init;
% fun =@c_obj;
% options = optimoptions(@fminunc, 'SpecifyObjectiveGradient', true,  'Display', 'iter', 'MaxIterations', 50); % 'CheckGradients', true, 'FiniteDifferenceStepSize', 1e-4
% [c,min_res] = fminunc(fun,x0,options);

addpath('lbfgsb3.0_mex1.2/L-BFGS-B-C-master/Matlab');
 fun = @(c) c_obj(c);
 l  = -inf*ones(train_num,1);
 u = inf*ones(train_num,1);
opts.factr = 1e-7;
opts.x0=c_init;
opts.maxIts=200;
opts.maxTotalIts=10000;
opts.pgtol=1e-6;
opts.m=1000;
opts.printEvery=1;

[c, min_res, ~] = lbfgsb(fun, l, u, opts);
end