function [v_r, v_tx, v_ty, v_s] = trans_dev(IN)

[m,n] = size(IN);

d = sqrt(n);

v_r = zeros(m,n);
v_tx = zeros(m,n);
v_ty = zeros(m,n);
v_s = zeros(m,n);


mx = repmat(1:d, d, 1);
my = repmat((1:d)', 1, d);

a = 1.5;
gaussian_dx = @(x,y)   -x.*exp(-(x.^2+y.^2)/(2.*a.^2))./(a.^2);
gaussian_dy = @(x,y)   -y.*exp(-(x.^2+y.^2)/(2.*a.^2))./(a.^2);

x = -2:2;
y = -2:2;
[X,Y] = meshgrid(x,y);

d1 = gaussian_dx(X,Y);
d2 = gaussian_dy(X,Y);
for i = 1:m
  
current = reshape(IN(i,:), [d,d]);
Cx= conv2(current, d1, 'same');
Cy=conv2(current, d2, 'same');
v_r (i,:) = reshape(my.*Cx-mx.*Cy, [1,d*d]);
v_tx(i,:) = reshape(Cx, [1,d*d]);
v_ty(i,:) = reshape(Cy, [1,d*d]);
v_s(i,:) = reshape(mx.*Cx-my.*Cy, [1,d*d]);

end