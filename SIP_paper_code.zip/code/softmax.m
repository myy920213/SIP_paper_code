
function  [loss, grad] = softmax(x, y)
        
        loss = 0;
        
        EXP = exp(x);
        ematrix = sum(EXP);
        EXP = bsxfun(@rdivide, EXP, ematrix);
        grad=zeros(size(x));
        
        for j = 1:length(y)
           loss = loss+ (-log(EXP(int8(y(j)), j)));
           g_current = EXP(:,j);
           g_current(int8(y(j))) = g_current(int8(y(j)))-1;
           grad(:,j) = g_current;
            
            
        end
         loss = loss/(length(y));
        grad = grad./(length(y));
        
  end