function [h, f_norm, M, opt_l, opt_res] = solve_dual_lbfgsb(l0, b, Z, a)
tol = 1e-6;
maxit = 30;
eps = 1e-10;
%b = -psi*c;
[d,n] = size(Z);
e = ones(n,1);
I = eye(d);
    function [f,g] = l_obj(l)
%         C = (sum(l)+eps)*I + bsxfun(@times, a*Z, l')*Z' ;
%         %inv_C = inv(C);
%         %C = (C+transpose(C))./2;
%         temp = C\b;
        
        function y = afun(x)
            y = a*Z*(l.*Z'*x) + (eps+sum(l))*x;
             %y = Z*(l.*Z'*x) + (eps+1.0)*x;
        end
        
        [temp, flag] = cgs(@afun, b, tol, maxit);

       f = 0.25*b'*temp + sum(l);
       %f = 0.25*b'*temp + 1.0;
        
        if nargout>1
            %temp = C\b;
            g =0.25*(-temp' * temp - a*(Z' * temp).^2 )+1.0;
           %g = -0.25*(Z' * temp).^2
            
        end
    end

% 
% x0 = l0;
% fun =@l_obj;
% options = optimoptions(@fminunc, 'SpecifyObjectiveGradient', true,  'Display', 'iter', 'CheckGradients', true, 'FiniteDifferenceStepSize', 1e-6);
% [p,min_res] = fminunc(fun,x0,options);



 addpath('lbfgsb3.0_mex1.2/L-BFGS-B-C-master/Matlab');
 fun = @(l) l_obj(l);
 L  = zeros(n,1);
 U = inf*ones(n,1);
opts.factr = 1e-7;
opts.x0=l0;
opts.maxIts=30;
opts.maxTotalIts=10000;
opts.pgtol=1e-3;
opts.m=1000;
opts.printEvery=1;
% 
% h = -b/norm(b);
% opt_l = norm(b)/2;
% f_norm = -transpose(b)*h;
% M = rand(d,d);
% opt_res = 1.0;
% 
% return
  
[opt_l, opt_res, ~] = lbfgsb(fun, L, U, opts);

M = (transpose(opt_l)*e*I + a*bsxfun(@times, Z, transpose(opt_l))*transpose(Z) + eps*I);
h = -0.5*(M\b);
%a=h'*(transpose(opt_l)*e*I + bsxfun(@times, Z, transpose(opt_l))*transpose(Z) + eps*I)*h;
f_norm = -transpose(b)*h;


end
        
    