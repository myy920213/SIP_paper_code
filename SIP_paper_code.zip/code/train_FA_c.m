function [opt_c, opt_loss] = train_FA_c(psi_train, H, f_norm, train_labels, lamb, c_init, verbose, psi_test, test_labels)

function [f,g] = c_obj(c)
        
        fx = psi_train' * H * c;
        [L, dLdfx] = hinge_loss(fx, train_labels);
        f = lamb * L + (f_norm' * c)^2;
         if nargout > 1
             g1 =lamb *  H' * psi_train * dLdfx;
             g2 = 2 * (f_norm' * c) * f_norm;
             g = g1 + g2;
             if verbose == true
                 train_output  = psi_train' * H * c;
                 train_predictions = train_output>=0;
                train_acc = sum(train_predictions==train_labels)/train_num;
                test_out = psi_test' * H * c;
                test_predictions = test_out>=0;
                test_acc = sum(test_predictions==test_labels)/test_num;
                fprintf('train_acc: %5.4f   test_acc: %5.4f', train_acc, test_acc);
             end
         end
         
end


x0 = c_init;
fun =@c_obj;
options = optimoptions(@fminunc, 'SpecifyObjectiveGradient', true,  'Display', 'iter'); % 'CheckGradients', true, 'FiniteDifferenceStepSize', 1e-6
[opt_c, opt_loss] = fminunc(fun,x0,options);


end

