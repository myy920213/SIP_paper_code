function [L, grad] = binary_loss(fx, label)
n_class = 1;    
n = length(label);
    function prob = sigmoid(input)
        prob = 1.0./(1.0+exp(-1.0*input));
        
    end

L =   -1*label.*log(sigmoid(fx))-(1-label).*log(sigmoid(-1*fx));
L (label==0)= L(label==0)/n_class;
L = sum(L)/n;

grad = sigmoid(fx)-label;
grad(label==0) = grad(label==0)/n_class;
grad = grad/n;

end