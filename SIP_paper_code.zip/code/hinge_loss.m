function [L, dLdfx] = hinge_loss(fx, labels)
n_class = 1;
labels(labels==0) =-1;
num = length(labels);
score = 1- labels.*fx;
score(labels==-1) = score(labels==-1)/n_class;
idx = find(score>0);
L = sum(score(idx))/num;
dLdfx = zeros(num,1);
dLdfx(idx) = -1 *labels(idx);
dLdfx(labels==-1) = dLdfx(labels==-1)/n_class;
dLdfx = dLdfx/num;

end
