function [c, min_res] = train_c_plain(psi_train, train_labels, lamb, c_init, verbose, psi_test, test_labels)
train_num = length(train_labels);
test_num = length(test_labels);
[d, n] = size(psi_train);

    function [f, g] = c_obj(c)
%         fx = transpose(psi_train)*psi_train*c;
%         [L, dLdfx] = binary_loss(fx, train_labels);
%         reg = transpose(c)*transpose(psi_train)*psi_train*c;
%         f = L + lamb*reg;
        fx = transpose(psi_train)*psi_train*(c);
        [L, dLdfx] = hinge_loss(fx, train_labels);
        reg = transpose(c)*transpose(psi_train)*psi_train*c;
        f = L + lamb*reg;
        if nargout > 1
%            term1 = psi_train' * psi_train * dLdfx;
%            term2 = lamb*2*transpose(psi_train)*psi_train*c;
%            g = term1 + term2;
           term1 = (psi_train') * psi_train*dLdfx; %(bsxfun(@times, psi_train, train_labels'))'
           term2 =lamb * 2*transpose(psi_train)*psi_train*c;
           g = term1 + term2;
            if verbose == true
                train_output = psi_train'*psi_train*c;
                train_predictions = train_output>=0;
                train_acc = sum(train_predictions==train_labels)/train_num;
                test_out = psi_test'*psi_train*c;
                test_predictions = test_out>=0;
                test_acc = sum(test_predictions==test_labels)/test_num;
                fprintf('train_acc: %5.4f   test_acc: %5.4f', train_acc, test_acc);
            end
        end
    end



% x0 = c_init;
% fun =@c_obj;
% options = optimoptions(@fminunc, 'MaxIterations', 10000, 'SpecifyObjectiveGradient', true,  'Display', 'iter');
% [c,min_res] = fminunc(fun,x0,options);

addpath('lbfgsb3.0_mex1.2/L-BFGS-B-C-master/Matlab');
 fun = @(c) c_obj(c);
 l  = -inf*ones(n,1);
 u = inf*ones(n,1);
opts.factr = 1e-7;
opts.x0=c_init;
opts.maxIts=150;
opts.maxTotalIts=10000;
opts.pgtol=1e-6;
opts.m=1000;
opts.printEvery=1;

[c, min_res, ~] = lbfgsb(fun, l, u, opts);

end