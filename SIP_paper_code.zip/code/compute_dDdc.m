function res = compute_dDdc(c, max_u, psi_train, invariance)

[d, n] = size(psi_train);
delta = 1e-3;

temp = zeros(n,d);

for i = 1:n
    d = c;
    d(i) = d(i)+delta;
    [opt_u, opt_res] = solve_sup(max_u, d, psi_train, invariance);
    temp(i,:) = transpose(opt_u-max_u)/delta;
end

res = temp*psi_train;